<?php

/**
 * Plugin Name: Zoho Sync Products
 * Description: Sincronización de productos con Zoho.
 * Version: 1.0
 * Author: Tu Nombre
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
