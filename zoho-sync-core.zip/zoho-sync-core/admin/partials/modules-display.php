<?php
// Vista para los módulos conectados