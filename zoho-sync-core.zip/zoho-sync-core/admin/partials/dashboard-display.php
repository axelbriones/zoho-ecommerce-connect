<?php
// Vista para el dashboard principal