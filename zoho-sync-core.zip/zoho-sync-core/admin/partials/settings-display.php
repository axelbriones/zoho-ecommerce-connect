<?php
// Vista para la configuración