<?php
// Vista para los logs