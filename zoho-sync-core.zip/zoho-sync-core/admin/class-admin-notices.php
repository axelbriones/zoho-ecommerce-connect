<?php

class Zoho_Sync_Core_Admin_Notices {}
