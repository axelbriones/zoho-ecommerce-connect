// Lógica para el dashboard de administración
