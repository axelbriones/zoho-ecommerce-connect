// Lógica para la validación de ajustes
