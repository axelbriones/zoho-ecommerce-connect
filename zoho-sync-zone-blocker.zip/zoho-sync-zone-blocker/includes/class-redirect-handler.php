<?php

class ZSZB_Redirect_Handler {
    public static function init() {
        // Hooks para gestionar redirecciones de usuarios bloqueados
    }
}